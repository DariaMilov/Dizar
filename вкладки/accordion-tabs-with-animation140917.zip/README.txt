A Pen created at CodePen.io. You can find this one at https://codepen.io/Benny29390/pen/zwyGxm.

 A simple tabs / accordions solution with jQuery, HTML and CSS.